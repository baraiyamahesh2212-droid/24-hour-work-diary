package com.hourworkdiary;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, hoursLayout;
    TextView dateTitle, countText;
    Calendar selected = Calendar.getInstance();
    SharedPreferences prefs;

    int blue = Color.rgb(11,99,206);
    int text = Color.rgb(23,32,51);
    int bg = Color.rgb(244,247,251);

    String key(int h) {
        return "day_" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(selected.getTime()) + "_" + h;
    }

    String hourLabel(int h) {
        int nh = (h + 1) % 24;
        String a = h < 12 ? "AM" : "PM";
        String b = nh < 12 ? "AM" : "PM";
        int hh = h % 12; if (hh == 0) hh = 12;
        int nn = nh % 12; if (nn == 0) nn = 12;
        return hh + ":00 " + a + " – " + nn + ":00 " + b;
    }

    GradientDrawable rounded(int color, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(24); g.setStroke(1, stroke);
        return g;
    }

    TextView title(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(text); t.setTextSize(size); t.setTypeface(null, 1);
        t.setPadding(6, 12, 6, 8); return t;
    }

    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setTextSize(14); b.setAllCaps(false);
        b.setBackground(rounded(blue, blue));
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("diary", MODE_PRIVATE);
        build();
    }

    void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 10, 12, 20); root.setBackgroundColor(bg);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(14,14,14,14); header.setBackground(rounded(blue,blue));
        ImageView logo = new ImageView(this); logo.setImageResource(com.hourworkdiary.R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo,new LinearLayout.LayoutParams(-1,180));
        TextView h = new TextView(this); h.setText("24 Hour Work Diary");
        h.setTextColor(Color.WHITE); h.setTextSize(24); h.setTypeface(null,1); h.setPadding(4,8,4,2);
        header.addView(h);
        TextView sub = new TextView(this); sub.setText("Your Time • Your Work • A Better You");
        sub.setTextColor(Color.WHITE); sub.setTextSize(14); header.addView(sub);
        root.addView(header);

        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(0,10,0,4);
        Button prev=button("‹"), today=button("Today"), next=button("›");
        nav.addView(prev,new LinearLayout.LayoutParams(0,55,1));
        nav.addView(today,new LinearLayout.LayoutParams(0,55,1));
        nav.addView(next,new LinearLayout.LayoutParams(0,55,1));
        root.addView(nav);

        dateTitle = title("",18); dateTitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER); root.addView(dateTitle);
        countText = title("",14); countText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER); root.addView(countText);

        hoursLayout = new LinearLayout(this); hoursLayout.setOrientation(LinearLayout.VERTICAL);
        root.addView(hoursLayout);

        prev.setOnClickListener(v->{selected.add(Calendar.DAY_OF_MONTH,-1); load();});
        next.setOnClickListener(v->{selected.add(Calendar.DAY_OF_MONTH,1); load();});
        today.setOnClickListener(v->{selected=Calendar.getInstance(); load();});

        setContentView(scroll);
        load();
    }

    void load() {
        dateTitle.setText(new SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.US).format(selected.getTime()));
        hoursLayout.removeAllViews();
        int count=0;
        for(int h=0;h<24;h++) {
            final int hour=h;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(12,10,12,10); card.setBackground(rounded(Color.WHITE,Color.rgb(225,231,239)));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT);
            cp.setMargins(0,7,0,0); card.setLayoutParams(cp);

            TextView time=title(hourLabel(h),15); time.setTextColor(blue); card.addView(time);

            EditText e=new EditText(this); e.setText(prefs.getString(key(h),""));
            e.setHint("What did you do in this hour?");
            e.setTextSize(15); e.setGravity(Gravity.TOP); e.setMinLines(3);
            e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setPadding(10,8,10,8); e.setBackground(rounded(Color.WHITE,Color.rgb(210,218,228)));
            card.addView(e,new LinearLayout.LayoutParams(-1,110));

            TextView saved=new TextView(this); saved.setText("Auto-saved ✓"); saved.setTextSize(11); saved.setTextColor(Color.rgb(23,166,115));
            card.addView(saved);
            e.setOnFocusChangeListener((v,has)-> { if(!has) save(hour,e,saved); });
            e.setOnKeyListener((v,event)-> { save(hour,e,saved); return false; });
            hoursLayout.addView(card);
            if(!e.getText().toString().trim().isEmpty()) count++;
        }
        countText.setText(count+" / 24 hourly boxes filled");
    }

    void save(int h, EditText e, TextView s) {
        prefs.edit().putString(key(h),e.getText().toString()).apply();
        s.setText("Saved ✓");
        refreshCount();
    }

    void refreshCount() {
        int n=0; for(int h=0;h<24;h++) if(!prefs.getString(key(h),"").trim().isEmpty()) n++;
        countText.setText(n+" / 24 hourly boxes filled");
    }
}