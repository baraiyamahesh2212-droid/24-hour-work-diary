# Play Store publishing checklist

1. Create/verify your Google Play Console developer account.
2. Open this project in Android Studio.
3. Set your final applicationId if desired.
4. Configure Firebase Phone Auth + cloud database using your own Firebase project.
5. Add real user profile, sync and leaderboard backend.
6. Add Play Billing/AdMob only after policy review and testing.
7. Create a signed Android App Bundle (.aab).
8. Prepare app icon, screenshots, feature graphic, description and privacy policy.
9. Complete Data Safety and other Play Console declarations accurately.
10. Run required testing and submit the release for review.

This project is a buildable source starting point; it is not a claim that a Play Store-ready production backend has been provisioned.
